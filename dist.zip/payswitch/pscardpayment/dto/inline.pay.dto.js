"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InlinePayDto = void 0;
class InlinePayDto {
}
exports.InlinePayDto = InlinePayDto;
//# sourceMappingURL=inline.pay.dto.js.map