export declare class CallbackDto {
    status: string;
    code: any;
    description: string;
    r_switch: string;
    subscriberNumber: string;
    amount: any;
    channel: string;
    currency: string;
    transactionId: string;
}
