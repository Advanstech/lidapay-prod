export declare class PscardpaymentModule {
}
