export declare class PsmobilemoneyModule {
}
