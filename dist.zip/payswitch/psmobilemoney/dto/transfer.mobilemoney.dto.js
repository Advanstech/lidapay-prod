"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransferMobileMoneyDto = void 0;
class TransferMobileMoneyDto {
}
exports.TransferMobileMoneyDto = TransferMobileMoneyDto;
//# sourceMappingURL=transfer.mobilemoney.dto.js.map