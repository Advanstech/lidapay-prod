export declare class TransactionModule {
}
