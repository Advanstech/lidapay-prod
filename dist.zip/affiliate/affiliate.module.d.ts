export declare class AffiliateModule {
}
