"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateAffiliateDto = void 0;
class CreateAffiliateDto {
}
exports.CreateAffiliateDto = CreateAffiliateDto;
//# sourceMappingURL=create.affiliate.dto.js.map