export declare class ReloadlyModule {
}
