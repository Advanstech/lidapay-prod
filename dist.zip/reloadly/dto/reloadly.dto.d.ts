export declare class ReloadlyDto {
    countryCode: string;
    isoCode: string;
}
