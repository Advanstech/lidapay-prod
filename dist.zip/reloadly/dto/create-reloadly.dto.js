"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateReloadlyDto = void 0;
class CreateReloadlyDto {
}
exports.CreateReloadlyDto = CreateReloadlyDto;
//# sourceMappingURL=create-reloadly.dto.js.map