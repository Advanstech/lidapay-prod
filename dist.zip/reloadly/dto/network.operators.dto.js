"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NetworkOperatorsDto = void 0;
class NetworkOperatorsDto {
}
exports.NetworkOperatorsDto = NetworkOperatorsDto;
//# sourceMappingURL=network.operators.dto.js.map