"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReloadlyDto = void 0;
class ReloadlyDto {
}
exports.ReloadlyDto = ReloadlyDto;
//# sourceMappingURL=reloadly.dto.js.map