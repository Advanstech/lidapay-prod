"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CountryReloadlyDto = void 0;
class CountryReloadlyDto {
}
exports.CountryReloadlyDto = CountryReloadlyDto;
//# sourceMappingURL=country-reloadly.dto.js.map