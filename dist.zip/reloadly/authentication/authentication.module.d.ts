export declare class AuthenticationModule {
}
