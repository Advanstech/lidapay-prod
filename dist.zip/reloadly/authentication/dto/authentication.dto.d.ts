export declare class AuthenticationDto {
    readonly clientId: 'string';
    readonly clientSecret: 'string';
    readonly grantType: 'string';
    readonly audience: 'string';
}
