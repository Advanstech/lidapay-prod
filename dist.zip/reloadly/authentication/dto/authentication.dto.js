"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthenticationDto = void 0;
class AuthenticationDto {
}
exports.AuthenticationDto = AuthenticationDto;
//# sourceMappingURL=authentication.dto.js.map