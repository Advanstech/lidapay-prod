export declare class ReloadAirtimeModule {
}
