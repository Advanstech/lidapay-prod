"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReloadAirtimeDto = void 0;
class ReloadAirtimeDto {
}
exports.ReloadAirtimeDto = ReloadAirtimeDto;
//# sourceMappingURL=reload.airtime.dto.js.map