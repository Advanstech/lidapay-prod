export declare class MobilemoneyModule {
}
