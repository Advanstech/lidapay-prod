"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReceiveMoneyDto = void 0;
class ReceiveMoneyDto {
}
exports.ReceiveMoneyDto = ReceiveMoneyDto;
//# sourceMappingURL=receive.money.dto.js.map