"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SendMoneyDto = void 0;
class SendMoneyDto {
}
exports.SendMoneyDto = SendMoneyDto;
//# sourceMappingURL=send.money.dto.js.map