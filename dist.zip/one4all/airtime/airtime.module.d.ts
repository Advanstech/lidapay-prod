export declare class AirtimeModule {
}
