"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TopupDto = void 0;
class TopupDto {
}
exports.TopupDto = TopupDto;
//# sourceMappingURL=topup.dto.js.map