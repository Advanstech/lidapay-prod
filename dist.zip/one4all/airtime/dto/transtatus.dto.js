"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransStatusDto = void 0;
class TransStatusDto {
}
exports.TransStatusDto = TransStatusDto;
//# sourceMappingURL=transtatus.dto.js.map