export declare class InternetModule {
}
