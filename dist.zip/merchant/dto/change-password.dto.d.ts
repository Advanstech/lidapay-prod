export declare class ChangePasswordDto {
    currentPassword: string;
    newPassword: string;
}
