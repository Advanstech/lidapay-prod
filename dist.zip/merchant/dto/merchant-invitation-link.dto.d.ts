export declare class MerchantInvitationLinkDto {
    usageCount: number;
    lastUsed: Date | null;
}
