"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateMerchantDto = void 0;
class CreateMerchantDto {
}
exports.CreateMerchantDto = CreateMerchantDto;
//# sourceMappingURL=create-merchant.dto.js.map