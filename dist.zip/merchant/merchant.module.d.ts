export declare class MerchantModule {
}
