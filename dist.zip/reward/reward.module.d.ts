export declare class RewardModule {
}
