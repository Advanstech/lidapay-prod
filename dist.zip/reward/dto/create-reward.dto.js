"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateRewardDto = void 0;
class CreateRewardDto {
}
exports.CreateRewardDto = CreateRewardDto;
//# sourceMappingURL=create-reward.dto.js.map