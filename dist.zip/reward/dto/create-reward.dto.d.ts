export declare class CreateRewardDto {
    readonly userId: string;
    readonly points: number;
}
