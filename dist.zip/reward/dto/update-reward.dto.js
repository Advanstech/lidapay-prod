"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateRewardDto = void 0;
class UpdateRewardDto {
}
exports.UpdateRewardDto = UpdateRewardDto;
//# sourceMappingURL=update-reward.dto.js.map