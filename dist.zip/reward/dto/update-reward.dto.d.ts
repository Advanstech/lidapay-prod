export declare class UpdateRewardDto {
    readonly points: number;
    readonly reason: string;
}
