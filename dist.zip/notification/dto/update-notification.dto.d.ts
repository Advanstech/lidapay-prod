export declare class UpdateNotificationDto {
    readonly status: string;
    type?: string;
}
