export declare class CreateNotificationDto {
    readonly userId: string;
    readonly type: string;
    readonly subject: string;
    readonly message: string;
}
