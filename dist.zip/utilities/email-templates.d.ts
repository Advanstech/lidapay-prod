export declare const EmailTemplates: {
    welcomeEmail: (firstName: string) => string;
    emailVerificationSuccess: (firstName: string) => string;
};
