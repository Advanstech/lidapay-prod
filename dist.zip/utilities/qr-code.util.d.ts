export declare function generateQrCode(userId: string): Promise<string>;
